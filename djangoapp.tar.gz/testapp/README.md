This is the basic app to manage users.

To run the app

1. download the git repo
2. run python manage.py migrate
3. run python manage.py runserver

* First you should install the Django 1.9

Please enjoy with the app.
